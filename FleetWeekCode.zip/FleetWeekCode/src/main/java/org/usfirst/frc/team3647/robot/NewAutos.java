// package org.usfirst.frc.team3647.robot;

// public class NewAutos extends Autonomous
// {
// 	public static void test(double lValue, double rValue)
// 	{
// 		switch(currentState)
// 		{
			
// 		}
// 	}
// }
